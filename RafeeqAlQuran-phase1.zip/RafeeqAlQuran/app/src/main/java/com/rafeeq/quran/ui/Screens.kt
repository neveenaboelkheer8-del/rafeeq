package com.rafeeq.quran.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rafeeq.quran.data.ThemeMode
import com.rafeeq.quran.ui.theme.Emerald
import com.rafeeq.quran.ui.theme.EmeraldDark
import com.rafeeq.quran.ui.theme.Gold
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

private val hijriMonths = listOf(
    "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
    "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
)

private fun hijriToday(): String {
    val h = HijrahDate.from(LocalDate.now())
    val day = h.get(ChronoField.DAY_OF_MONTH)
    val month = hijriMonths[h.get(ChronoField.MONTH_OF_YEAR) - 1]
    val year = h.get(ChronoField.YEAR)
    return "$day $month $year هـ"
}

@Composable
fun HomeScreen(onOpen: (Dest) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.verticalGradient(listOf(EmeraldDark, Emerald)))
                .statusBarsPadding().padding(24.dp)
        ) {
            Column {
                Text("رفيق القرآن", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(hijriToday(), color = Color.White, fontSize = 16.sp)
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("أقسام التطبيق", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Dest.entries.filter { it != Dest.Home }.forEach { d ->
                Card(
                    Modifier.fillMaxWidth().clickable { onOpen(d) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(d.icon, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Text(d.label, fontSize = 17.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun PlaceholderScreen(title: String, phase: String, planned: String) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text("هذا القسم لم يُنفَّذ بعد، وسيُبنى في $phase.", fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Text(planned, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SettingsScreen(mode: ThemeMode, onChange: (ThemeMode) -> Unit) {
    val options = listOf(
        ThemeMode.SYSTEM to "حسب النظام",
        ThemeMode.LIGHT to "نهاري",
        ThemeMode.DARK to "ليلي"
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text("الإعدادات", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Text("المظهر", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        options.forEach { (m, label) ->
            Row(
                Modifier.fillMaxWidth().clickable { onChange(m) }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = mode == m, onClick = { onChange(m) })
                Text(label, fontSize = 16.sp)
            }
        }
    }
}
