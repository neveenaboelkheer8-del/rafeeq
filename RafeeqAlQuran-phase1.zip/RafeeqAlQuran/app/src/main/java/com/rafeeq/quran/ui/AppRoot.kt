package com.rafeeq.quran.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.rafeeq.quran.data.ThemeMode

enum class Dest(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "الرئيسية", Icons.Filled.Home),
    Quran("quran", "المصحف", Icons.Filled.MenuBook),
    Memorize("memorize", "الحفظ", Icons.Filled.School),
    Adhkar("adhkar", "الأذكار", Icons.Filled.WbSunny),
    Settings("settings", "الإعدادات", Icons.Filled.Settings)
}

@Composable
fun AppRoot(themeMode: ThemeMode, onThemeChange: (ThemeMode) -> Unit) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route

    fun go(d: Dest) = nav.navigate(d.route) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                Dest.entries.forEach { d ->
                    NavigationBarItem(
                        selected = current == d.route,
                        onClick = { go(d) },
                        icon = { Icon(d.icon, contentDescription = d.label) },
                        label = { Text(d.label) }
                    )
                }
            }
        }
    ) { inner ->
        NavHost(nav, startDestination = Dest.Home.route, modifier = Modifier.padding(inner)) {
            composable(Dest.Home.route) { HomeScreen(onOpen = ::go) }
            composable(Dest.Quran.route) { PlaceholderScreen("المصحف الشريف", "المرحلة 2", "نص القرآن بالرسم العثماني، البحث، العلامات المرجعية، الأجزاء والأحزاب.") }
            composable(Dest.Memorize.route) { PlaceholderScreen("الحفظ", "المرحلة 4", "التكرار بصوت الحصري، الاختبار بإخفاء النص، المراجعة، الخطط والتقدم.") }
            composable(Dest.Adhkar.route) { PlaceholderScreen("الأذكار", "المرحلة 5", "أذكار الصباح والمساء والنوم، عداد التسبيح، وكتاب حصن المسلم.") }
            composable(Dest.Settings.route) { SettingsScreen(themeMode, onThemeChange) }
        }
    }
}
