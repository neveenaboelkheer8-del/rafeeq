package com.rafeeq.quran.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Emerald = Color(0xFF0B6B4F)
val EmeraldDark = Color(0xFF064E3B)
val EmeraldLight = Color(0xFF3FAE8A)
val Gold = Color(0xFFC9A227)
val Ivory = Color(0xFFFAF8F1)

private val LightColors = lightColorScheme(
    primary = Emerald, onPrimary = Color.White,
    primaryContainer = Color(0xFFD5EFE5), onPrimaryContainer = EmeraldDark,
    secondary = Gold, onSecondary = Color.White,
    secondaryContainer = Color(0xFFF6EBC4), onSecondaryContainer = Color(0xFF4A3B00),
    background = Ivory, onBackground = Color(0xFF1B1B18),
    surface = Color.White, onSurface = Color(0xFF1B1B18),
    surfaceVariant = Color(0xFFEFEBDD), onSurfaceVariant = Color(0xFF49463C)
)

private val DarkColors = darkColorScheme(
    primary = EmeraldLight, onPrimary = Color(0xFF00382A),
    primaryContainer = EmeraldDark, onPrimaryContainer = Color(0xFFD5EFE5),
    secondary = Color(0xFFE5C65A), onSecondary = Color(0xFF3B2F00),
    secondaryContainer = Color(0xFF5A4700), onSecondaryContainer = Color(0xFFF6EBC4),
    background = Color(0xFF0E1A16), onBackground = Color(0xFFE6E3D9),
    surface = Color(0xFF14241E), onSurface = Color(0xFFE6E3D9),
    surfaceVariant = Color(0xFF22332C), onSurfaceVariant = Color(0xFFC6C4B8)
)

@Composable
fun RafeeqTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
